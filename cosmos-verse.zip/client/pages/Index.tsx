import HeroSection from '../components/HeroSection';
import AboutSection from '../components/AboutSection';
import SkillsSection from '../components/SkillsSection';
import EducationSection from '../components/EducationSection';
import ExperienceSection from '../components/ExperienceSection';
import ProjectsSection from '../components/ProjectsSection';
import ContactSection from '../components/ContactSection';
import Footer from '../components/Footer';

interface IndexProps {
  language: string;
  theme: string;
}

const Index = ({ language, theme }: IndexProps) => {
  return (
    <div className="min-h-screen">
      <HeroSection language={language} />
      <AboutSection language={language} />
      <SkillsSection language={language} />
      <EducationSection language={language} />
      <ExperienceSection language={language} />
      <ProjectsSection language={language} />
      <ContactSection language={language} />
      <Footer language={language} />
    </div>
  );
};

export default Index;
